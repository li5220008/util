#!/bin/sh
tail -f /var/data/tungsten/replication2queue/master/tungsten/tungsten-replicator/log/trepsvc.log
