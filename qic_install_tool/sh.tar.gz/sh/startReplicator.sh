#!/bin/sh
export JAVA_HOME=/usr/local/jdk1.6.0_33
export ANT_HOME=/usr/local/ant184
export M2_HOME=/usr/local/maven304

export PATH=$PATH:/usr/local/mysql/bin:$JAVA_HOME/bin:$ANT_HOME/bin:$M2_HOME/bin

/var/data/tungsten/replication2queue/master/tungsten/tungsten-replicator/bin/replicator start
