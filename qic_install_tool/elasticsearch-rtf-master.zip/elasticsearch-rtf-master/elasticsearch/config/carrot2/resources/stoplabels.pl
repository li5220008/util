(?i)strona.*
