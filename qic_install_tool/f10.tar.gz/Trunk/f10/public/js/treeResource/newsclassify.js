var newsClassify = [
    {
        text:'新闻分类',
        isexpand:false,
        children:[
            {text:'宏观经济',code:'1'},
            {text:'政策动向',code:'2'},
            {text:'市场动态',code:'3'},
            {text:'产业新闻',code:'4'},
            {text:'公司动态',code:'5'},
            {text:'基金要闻',code:'6'},
            {text:'债券要闻',code:'7'},
            {text:'外汇期货',code:'8'},
            {text:'全球市场',code:'9'}
        ]
    }
];