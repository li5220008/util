var charConstText = '数据来源，国泰安资讯研究中心';
var charConstURL= 'http://www.gtadata.com/';