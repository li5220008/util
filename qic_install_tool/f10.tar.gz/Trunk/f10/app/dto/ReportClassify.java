package dto;

import java.util.List;

/**
 * 研报分类
 * User: panzhiwei
 * Date: 13-1-17
 * Time: 下午5:15
 * To change this template use File | Settings | File Templates.
 */
public class ReportClassify {
    public String name;
    public String code;
    public List<ReportClassify> children;

}
