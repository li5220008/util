package dto;

/**
 * 新闻附件
 * User: liangbing
 * Date: 13-2-22
 * Time: 下午5:28
 */
public class NewsAccessoryDto {

    public String fullName;
    public String accessOryroute;
    public String  filenameExtension;

}
