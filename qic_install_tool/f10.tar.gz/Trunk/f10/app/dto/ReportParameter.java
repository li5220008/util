package dto;

/**
 * Created with IntelliJ IDEA.
 * User: panzhiwei
 * Date: 13-1-19
 * Time: 上午11:08
 * To change this template use File | Settings | File Templates.
 */
public class ReportParameter {
    //ReportQueryParam
    public String classCode;        //类型分类
    public String childrenCode;     //行业分类
    public String keywords;         //关键字
    public Long id;                 //订阅id
}
