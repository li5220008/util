package dto.financeana;

/**
 * User: wenzhihong
 * Date: 12-12-22
 * Time: 上午9:28
 */
public class LcDiscloseIndexItem {
    public String enddateStr;

    public double roe;/*加权平均净资产收益率(%)*/
}
