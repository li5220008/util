package dto;

/**
 * 股票代码和简称
 * User: liangbing
 * Date: 13-5-15
 * Time: 上午9:28
 */
public class StockInfoDto {

    public String symbol; //代码
    public String shortname; //简称
    public String pyshortname ;//拼音简称

}
