package dbutils.combhandler;

/**
 * 这只是一个标识性接口, 用于标识是组合的Handler
 * User: wenzhihong
 * Date: 12-10-15
 * Time: 下午5:07
 */
public interface CombHandler {
}
