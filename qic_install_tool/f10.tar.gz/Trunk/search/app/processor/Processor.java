package processor;

import models.ResponseModel;

/**
 * User: 刘建力(liujianli@gtadata.com))
 * Date: 13-3-26
 * Time: 下午2:25
 * 功能描述:
 */
public interface Processor {

     public ResponseModel process();

}
