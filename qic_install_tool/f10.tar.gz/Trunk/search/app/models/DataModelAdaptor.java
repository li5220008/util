package models;

/**
 * User: 刘建力(liujianli@gtadata.com))
 * Date: 13-3-28
 * Time: 下午2:20
 * 功能描述:
 */
public abstract class DataModelAdaptor implements DataModel{

    public String toJson(){
        return null;
    }


}
