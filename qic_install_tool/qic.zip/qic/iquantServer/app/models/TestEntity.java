package models;

import play.db.jpa.Model;

import javax.persistence.Entity;

/**
 * User: 刘建力(liujianli@gtadata.com))
 * Date: 13-11-11
 * Time: 上午11:01
 * 功能描述:
 */
@Entity
public class TestEntity extends Model {
}
