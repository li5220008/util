package bussiness.stock.impl;


import bussiness.common.impl.BaseService;

/**
 * 股票池收藏
 * User: panzhiwei
 * Date: 12-11-19
 * Time: 上午11:43
 * To change this template use File | Settings | File Templates.
 */
public class StockPoolCollectService extends BaseService {



}
