package bussiness.stock.impl;

import bussiness.common.impl.BaseService;

/**
 * 股票池组合浏览基本业务类 我的收藏
 * User: liangbing
 * Date: 12-11-23
 * Time: 上午11:06
 * To change this template use File | Settings | File Templates.
 */
public class StockPoolFavoriteService extends BaseService {



}
