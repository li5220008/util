package bussiness.stock.impl;

import bussiness.common.impl.BaseService;

public class StockPoolBasicInfoService extends BaseService {

}
