package bussiness.stock.impl;

import bussiness.common.impl.BaseService;

/**
 * 股票池组合列表信息查看
 * User: panzhiwei
 * Date: 12-11-21
 * Time: 上午10:48
 * To change this template use File | Settings | File Templates.
 */
public class StockPoolCombineInfoService extends BaseService {

}
