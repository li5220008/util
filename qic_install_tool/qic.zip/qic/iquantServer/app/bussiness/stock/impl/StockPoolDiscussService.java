package bussiness.stock.impl;

import bussiness.common.impl.BaseService;

/**
 * User: liuhongjiang
 * Date: 12-11-20
 * Time: 上午9:47
 */
public class StockPoolDiscussService extends BaseService {


}
