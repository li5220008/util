package job;

/**
 * User: 刘建力(liujianli@gtadata.com))
 * Date: 13-8-19
 * Time: 下午2:53
 * 功能描述:
 */
public class ConvertAccountJob {

    public void doConvert(){
       /*查找产品策略对应关系*/
       /*select * from virtual_product_strategy*/
          /*查找产品交易账号对应关系*/
     /*select * from virtual_product_trade_account*/
     /*插入策略账号对应关系表insert into strategy_trade_account*/
    }
}
