#!/bin/bash
./cookbook/test_cluster.sh NODES_FAN_IN.sh
