#!/bin/bash
./cookbook/clear_cluster.sh NODES_STAR.sh
