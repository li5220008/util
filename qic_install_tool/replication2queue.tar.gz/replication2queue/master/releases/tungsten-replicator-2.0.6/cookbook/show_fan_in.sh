#!/bin/bash
./cookbook/show_cluster.sh NODES_FAN_IN.sh
