#!/bin/bash
./cookbook/clear_cluster.sh NODES_MASTER_SLAVE.sh
