#!/bin/bash
./cookbook/clear_cluster.sh NODES_ALL_MASTERS.sh
