#!/bin/bash
./cookbook/show_cluster.sh NODES_MASTER_SLAVE.sh
