#!/bin/bash
./cookbook/show_cluster.sh NODES_STAR.sh
