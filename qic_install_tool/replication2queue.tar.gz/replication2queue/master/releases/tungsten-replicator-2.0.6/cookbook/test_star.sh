#!/bin/bash
./cookbook/test_cluster.sh NODES_STAR.sh
