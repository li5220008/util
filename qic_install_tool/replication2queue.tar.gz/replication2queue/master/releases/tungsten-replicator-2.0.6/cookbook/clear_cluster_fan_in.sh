#!/bin/bash
./cookbook/clear_cluster.sh NODES_FAN_IN.sh
