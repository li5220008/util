#!/bin/bash
./cookbook/test_cluster.sh NODES_MASTER_SLAVE.sh
