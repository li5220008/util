#!/bin/bash
./cookbook/test_cluster.sh NODES_ALL_MASTERS.sh
