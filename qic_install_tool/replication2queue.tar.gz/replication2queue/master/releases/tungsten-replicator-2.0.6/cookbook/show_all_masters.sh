#!/bin/bash
./cookbook/show_cluster.sh NODES_ALL_MASTERS.sh
